import com.rabbitmq.client.AMQP;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.BuiltinExchangeType;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.Consumer;
import com.rabbitmq.client.DefaultConsumer;
import com.rabbitmq.client.Envelope;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;


public class Admin1 {

    public static void main(String[] argv) throws Exception {

        // info
        System.out.println("#### ADMIN PANEL ###");

        // connection & channel
        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost("localhost");
        Connection connection = factory.newConnection();
        Channel channel = connection.createChannel();

        // exchange
        String EXCHANGE_NAME = "test1";
        channel.exchangeDeclare(EXCHANGE_NAME, BuiltinExchangeType.TOPIC);
        String EXCHANGE_NAME_2 = "test2";
        channel.exchangeDeclare(EXCHANGE_NAME_2, BuiltinExchangeType.TOPIC);
        String EXCHANGE_NAME_3 = "test40";
        channel.exchangeDeclare(EXCHANGE_NAME_3, BuiltinExchangeType.TOPIC);

        // queue & bind
        String queueName = channel.queueDeclare().getQueue();
        channel.queueBind(queueName, EXCHANGE_NAME, "#");
        channel.queueBind(queueName, EXCHANGE_NAME_2, "#");
        channel.queueBind(queueName, EXCHANGE_NAME_3, "#");
        System.out.println("\tcreated queue: " + queueName + ", for 3 exchanges with key: #");

//        channel.basicQos(1);

        // consumer (message handling)
        Consumer consumer = new DefaultConsumer(channel) {
            @Override
            public void handleDelivery(String consumerTag, Envelope envelope, AMQP.BasicProperties properties, byte[] body) throws IOException {
                String msg1 = new String(body, StandardCharsets.UTF_8);
                String msg2 = envelope.getRoutingKey();
                var isExchangeOne = envelope.getExchange().equals(EXCHANGE_NAME);
                var isExchangeThree = envelope.getExchange().equals(EXCHANGE_NAME_3);

                if (msg2.contains("helloWorld.")){
                    if(msg2.contains("band"))
                        System.out.println("@@@ NEW BAND @@@ name: " + msg1);
                    else{
                        var name = msg1.split("::")[0];
                        var products = msg1.split("::")[1];
                        System.out.println("@@@ NEW PROVIDER @@@ name: " + name + ", products: " + products);
                    }
                }
                else if (isExchangeThree){
                    System.out.println("ADMIN MSG: " + msg1 + ", sent to: " + msg2);
                }
                else if (isExchangeOne)
                    System.out.println("MSG: new order! -> item: " + msg2 + ", from Band: " + msg1);
                else
                    System.out.println("MSG: ready item! -> " + msg1 + ", for band: " + msg2);
            }
        };

        // start listening
        System.out.println("\tWaiting for messages...");
        channel.basicConsume(queueName, false, consumer);

        while (true) {

            // read msg
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            System.out.println("--- Enter (prov|band|all) -> message or type exit: ---");
            String message = br.readLine();

            // break condition
            if ("exit".equals(message)) {
                break;
            }
            var key = message.split("->")[0].replaceAll("\\s+","");
            message = message.split("->")[1];

            //publish
            switch (key) {
                case "prov" -> {
                    channel.basicPublish(EXCHANGE_NAME_3, "provider", null, message.getBytes(StandardCharsets.UTF_8));
                    System.out.println("Sent to all providers: " + message);
                }
                case "band" -> {
                    channel.basicPublish(EXCHANGE_NAME_3, "band", null, message.getBytes(StandardCharsets.UTF_8));
                    System.out.println("Sent to all bands: " + message);
                }
                case "all" -> {
                    channel.basicPublish(EXCHANGE_NAME_3, "provider", null, message.getBytes(StandardCharsets.UTF_8));
                    channel.basicPublish(EXCHANGE_NAME_3, "band", null, message.getBytes(StandardCharsets.UTF_8));
                    System.out.println("Sent to all: " + message);
                }
            }

        }

        // close
        channel.close();
        connection.close();
    }
}