import com.rabbitmq.client.AMQP;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.BuiltinExchangeType;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.Consumer;
import com.rabbitmq.client.DefaultConsumer;
import com.rabbitmq.client.Envelope;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;


public class Provider2 {

    public static void main(String[] argv) throws Exception {

        //data
        String[] keys = new String[]{"tlen", "plecak"};
        int timeToSleep = 5;
        ScheduledThreadPoolExecutor exec = new ScheduledThreadPoolExecutor(10);

        // info
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Podaj nazwę dostawcy: ");
        String SELF_NAME = br.readLine();
        System.out.println("Dostawca: " + SELF_NAME + " " + Arrays.toString(keys));

        // connection & channel
        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost("localhost");
        Connection connection = factory.newConnection();
        Channel channel = connection.createChannel();

        // exchange
        String EXCHANGE_NAME = "test1";
        channel.exchangeDeclare(EXCHANGE_NAME, BuiltinExchangeType.TOPIC);
        String EXCHANGE_NAME_2 = "test2";
        channel.exchangeDeclare(EXCHANGE_NAME_2, BuiltinExchangeType.TOPIC);
        String EXCHANGE_NAME_3 = "test40";
        channel.exchangeDeclare(EXCHANGE_NAME_3, BuiltinExchangeType.TOPIC);

        //init message
        String HELLO_WORLD = SELF_NAME.concat("::").concat(Arrays.toString(keys));
        channel.basicPublish(EXCHANGE_NAME_3, "helloWorld.provider", null, HELLO_WORLD.getBytes(StandardCharsets.UTF_8));

        // queue & bind
        ArrayList<String> queues = new ArrayList<>();
        for (var key : keys){
            String queueName = channel.queueDeclare(key, false, false, false, null).getQueue();
            channel.queueBind(queueName, EXCHANGE_NAME, key);
            queues.add(queueName);
            System.out.println("created queue: " + queueName + ", with key: " + key);
        }

        //admin queue
        String adminQueueName = channel.queueDeclare().getQueue();
        channel.queueBind(adminQueueName, EXCHANGE_NAME_3, "provider");
        queues.add(adminQueueName);
        System.out.println("created queue: " + adminQueueName+ ", with key: provider");

//        channel.basicQos(1);

        // consumer (message handling)
        Consumer consumer = new DefaultConsumer(channel) {
            @Override
            public void handleDelivery(String consumerTag, Envelope envelope, AMQP.BasicProperties properties, byte[] body) throws IOException {
                String bandName = new String(body, StandardCharsets.UTF_8);
                String orderItem = envelope.getRoutingKey();
                if(envelope.getExchange().equals(EXCHANGE_NAME_3)){
                    System.out.println("ADMIN MSG: " + bandName);
                }
                else {
                    UUID uuid = UUID.randomUUID();
                    var orderKey = bandName.concat("#").concat(uuid.toString());

                    System.out.println("Received order for : " + orderItem + ", from Band: " + bandName);
                    System.out.println("\tstarting processing new order no: " + orderKey);

                    exec.schedule(() -> {
                        try {
                            channel.basicPublish(EXCHANGE_NAME_2, bandName, null, orderItem.getBytes(StandardCharsets.UTF_8));
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        System.out.println("\t\tprocessing order no: " + orderKey + " ended");
                    }, timeToSleep, TimeUnit.SECONDS);
                }
                channel.basicAck(envelope.getDeliveryTag(), false);
            }
        };

        // start listening
        System.out.println("\tWaiting for messages...");
        for (var queueName : queues){
            channel.basicConsume(queueName, false, consumer);
        }
    }
}