import com.rabbitmq.client.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Hashtable;
import java.util.Map;

public class Band1 {

    public static void main(String[] argv) throws Exception {

        //data
        String[] ourOrder = new String[]{"tlen", "tlen", "buty", "buty", "plecak", "plecak"};

        //utils
        Map<String, Integer> ordersCompleted = new Hashtable<>();
        for (var item : ourOrder){
            if(ordersCompleted.containsKey(item))
                ordersCompleted.put(item, ordersCompleted.get(item) + 1);
            else
                ordersCompleted.put(item, 1);
        }

        // info
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("Podaj nazwę ekipy: ");
        String SELF_NAME = br.readLine();
        SELF_NAME = SELF_NAME.replaceAll("\\s+","");
        System.out.println("Ekipa: " + SELF_NAME);

        // connection & channel
        ConnectionFactory factory = new ConnectionFactory();
        factory.setHost("localhost");
        Connection connection = factory.newConnection();
        Channel channel = connection.createChannel();

        // exchange
        String EXCHANGE_NAME = "test1";
        channel.exchangeDeclare(EXCHANGE_NAME, BuiltinExchangeType.TOPIC);
        String EXCHANGE_NAME_2 = "test2";
        channel.exchangeDeclare(EXCHANGE_NAME_2, BuiltinExchangeType.TOPIC);
        String EXCHANGE_NAME_3 = "test40";
        channel.exchangeDeclare(EXCHANGE_NAME_3, BuiltinExchangeType.TOPIC);

        //init message
        channel.basicPublish(EXCHANGE_NAME_3, "helloWorld.band", null, SELF_NAME.getBytes(StandardCharsets.UTF_8));

        //response queue
        String queueName = channel.queueDeclare().getQueue();
        channel.queueBind(queueName, EXCHANGE_NAME_2, SELF_NAME);
        System.out.println("\tcreated queue: " + queueName + ", with key: " + SELF_NAME);

        //admin queue
        String adminQueueName = channel.queueDeclare().getQueue();
        channel.queueBind(adminQueueName, EXCHANGE_NAME_3, "band");
        System.out.println("\tcreated queue: " + adminQueueName + ", with key: band");

        Consumer consumer = new DefaultConsumer(channel) {
            @Override
            public void handleDelivery(String consumerTag, Envelope envelope, AMQP.BasicProperties properties, byte[] body) throws IOException {
                String itemReady = new String(body, StandardCharsets.UTF_8);
                if(envelope.getExchange().equals(EXCHANGE_NAME_3)){
                    System.out.println("ADMIN MSG: " + itemReady);
                }
                else {
                    System.out.println("\tReceived product: " + itemReady);
                    if (ordersCompleted.containsKey(itemReady))
                        ordersCompleted.put(itemReady, ordersCompleted.get(itemReady) - 1);
                    if (ordersCompleted.get(itemReady) == 0)
                        ordersCompleted.remove(itemReady);
                    if (ordersCompleted.isEmpty())
                        System.out.println("ALL PRODUCTS RECEIVED");
                }
            }
        };

        // start listening
        System.out.println("\tWaiting for messages...");
        channel.basicConsume(queueName, true, consumer);
        channel.basicConsume(adminQueueName, true, consumer);

        // publish
        for (var orderPart : ourOrder) {
            channel.basicPublish(EXCHANGE_NAME, orderPart, null, SELF_NAME.getBytes(StandardCharsets.UTF_8));
            System.out.println("Sent order for: " + orderPart);
        }

    }
}
